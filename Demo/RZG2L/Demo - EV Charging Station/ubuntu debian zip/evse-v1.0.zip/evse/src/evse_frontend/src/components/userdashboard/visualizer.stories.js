/* eslint-disable */
import Visualizer from './Visualizer';

export default {
  title: "Visualizer",
};

export const Default = () => <Visualizer />;

Default.story = {
  name: 'default',
};
