import React from 'react';
import PropTypes from 'prop-types';

const Dashboard = () => (
  <div>
    Dashboard
  </div>
);

Dashboard.propTypes = {};

Dashboard.defaultProps = {};

export default Dashboard;
