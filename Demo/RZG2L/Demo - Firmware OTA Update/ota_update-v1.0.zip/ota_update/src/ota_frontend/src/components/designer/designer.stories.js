/* eslint-disable */
import Designer from './Designer';

export default {
  title: "Designer",
};

export const Default = () => <Designer />;

Default.story = {
  name: 'default',
};
