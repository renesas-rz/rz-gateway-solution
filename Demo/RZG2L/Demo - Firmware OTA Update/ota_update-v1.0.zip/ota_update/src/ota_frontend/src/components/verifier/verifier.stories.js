/* eslint-disable */
import Verifier from './Verifier';

export default {
  title: "Verifier",
};

export const Default = () => <Verifier />;

Default.story = {
  name: 'default',
};
