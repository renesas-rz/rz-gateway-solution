import React, { useEffect, useState } from "react";

import {Box, Typography } from "@mui/material";

export default function DeviceStatus(){
    console.log("hhii")
return(
    <Box>
        <Typography>Device is inactive</Typography>
    </Box>
)
}